var input = document.querySelector("#numInput"),
    buttons = document.querySelector(".buttons"),
    showPane = document.querySelector("#show-pane"),
    numQueue = [];

var showColor = ["rgb(66, 171, 167)","rgb(156, 235, 76)","rgb(228, 96, 153)","rgb(237, 92, 108)"];


function addEvent(element, type, handler) {
    if (element.addEventListener) {
        element.addEventListener(type, handler, false);
    } else if (element.attachEvent) {
        element.attachEvent("on" + type, handler);
    } else {
        element["on" + type] = handler;
    }
}
function getEvent(event) {
    return event ? event : window.event;
}
function getTarget(event) {
    return event.target || event.srcElement;
}


function checkInput(value) {
    if(numQueue.length >= 60) {
        alert("输入超过60个");
    }
    if(value == '') {
        alert("请输入插入数字");
        return 0;
    }
     return 1;
}

/* 渲染队列*/
function renderPane() {
    var showInner = '';
        for (var num in numQueue) {
            if (numQueue.hasOwnProperty(num)) {
                showInner += "<div class='itemTip'>" + numQueue[num] + "</div>";
            }
        }
    showPane.innerHTML = showInner;
}

/*触发事件*/
function leftIn(num) {
    numQueue.unshift(num);
    renderPane();
}
function rightIn(num) {
    numQueue.push(num);
    renderPane();
}
function leftOut(num) {
    numQueue.shift(num);
    renderPane();
}
function rightOut(num) {
    numQueue.pop(num);
    renderPane();
}


/*为4个按钮增加点击事件*/
function initQueue() {
    addEvent(buttons, "click", function(event) {
        event = getEvent(event);
        var target = getTarget(event),
            num = input.value.trim();
        if(checkInput(num)) {
            switch (target.id) {
                case "left-in": leftIn(num); break;
                case "right-in": rightIn(num); break;
                case "left-out": leftOut(num); break;
                case "right-out": rightOut(num); break;
                default: alert("target.id error");
            }
        }
    });
}

initQueue();